package it.unimore.fum.iot.resource;

import it.unimore.fum.iot.model.PeopleCounterDescriptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.math.*;

public class PresenceSensorResource extends PeopleCounterSmartObjectResource<PeopleCounterDescriptor> {

    private static final Logger logger = LoggerFactory.getLogger(TemperatureSensorResource.class);

    private PeopleCounterDescriptor updatedPeopleCounterDescriptor = null;

    private static final long UPDATE_PERIOD = 1000; //5 Seconds

    private static final long TASK_DELAY_TIME = 5000; //Seconds before starting the periodic update task

    public static final String RESOURCE_TYPE = "iot:peoplecountersensor:presence";

    public static final PeopleCounterDescriptor UpdatedPeopleCounterDescriptor = null;

    private int updatedPresenceIn;

    private int updatedPresenceOut;

    private Timer updateTimer = null;

    private Integer randomIn;

    private Integer randomOut;

    public PresenceSensorResource() {
        super(UUID.randomUUID().toString(), PresenceSensorResource.RESOURCE_TYPE);
        init();
    }

    public PresenceSensorResource(String id, String type) {
        super(id, type);
        init();
    }

    private void init() {
        try {

            Random random1 = new Random();
            // genera numero casuale tra 0 e 3
            randomIn = random1.nextInt(4);

            Random random2 = new Random();
            // genera numero casuale tra 0 e 3
            randomOut = random2.nextInt(4);


            this.updatedPeopleCounterDescriptor = new PeopleCounterDescriptor(
                    UpdatedPeopleCounterDescriptor.getIn(),
                    updatedPeopleCounterDescriptor.getOut());

            this.updatedPresenceIn = randomIn;
            this.updatedPresenceOut = randomOut;
/**            Random randomIn = new Random();

 int randomIn = randomIn.nextInt(4);

 updatedPresenceIn = randomIn;
 */

/**            this.randomIn = new Random();
 this.randomIn = new randomIn.nextInt(10);
 this.randomOut = new Random(System.currentTimeMillis());
 */
            logger.info("GPX File WayPoint correctly loaded !");

            startPeriodicEventValueUpdateTask();

/**                    this.random.nextBoolean();
*/
        }catch (Exception e) {
            logger.error("Error init Presence Resource Object ! Msg: {}", e.getLocalizedMessage());
        }
    }

    private void startPeriodicEventValueUpdateTask() {
        try{

            logger.info("Starting periodic Update Task with Period: {} ms", UPDATE_PERIOD);

            this.updateTimer = new Timer();
            this.updateTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    Random random1 = new Random();
                    // genera numero casuale tra 0 e 3
                    randomIn = random1.nextInt(4);

                    Random random2 = new Random();
                    // genera numero casuale tra 0 e 3
                    randomOut = random2.nextInt(4);


                    updatedPresenceIn = (updatedPresenceIn + random1.nextInt(4));
                    updatedPresenceOut = updatedPresenceOut + random2.nextInt(4);
                    updatedPeopleCounterDescriptor = new PeopleCounterDescriptor(
                            UpdatedPeopleCounterDescriptor.getIn(),
                            updatedPeopleCounterDescriptor.getOut());
//                            updatedPeopleCounterDescriptor.RANDOM_PROVIDER);

                    notifyUpdatePC(updatedPeopleCounterDescriptor);
                }
            }, TASK_DELAY_TIME, UPDATE_PERIOD);


        }catch (Exception e) {
            logger.error("Error executing periodic resource value ! Msg: {}", e.getLocalizedMessage());
        }
    }

    @Override
    public PeopleCounterDescriptor loadUpdatedValuePC() {
        return this.updatedPeopleCounterDescriptor;
    }

    public static void main(String[] args) {
        PresenceSensorResource presenceSensorResource = new PresenceSensorResource();

        logger.info("New {} Resource Created with Id: {} ! Updated Value: {}",
                presenceSensorResource.getType(),
                presenceSensorResource.getId());
//                presenceSensorResource.loadUpdatedValuePC()


        presenceSensorResource.addDataListenerPC(new ResourceDataListenerPC<PeopleCounterDescriptor>() {
            @Override
            public void onDataChanged(PeopleCounterSmartObjectResource<PeopleCounterDescriptor> resource, PeopleCounterDescriptor updatedValue) {
                if (resource != null && updatedValue != null)
                    logger.info("Device: {} -> New Value Received: {}", resource.getId(), updatedValue);
                else
                    logger.error("onDataChanged Callback -> Null Resource or Updated Value !");
            }
        });

    }
}


