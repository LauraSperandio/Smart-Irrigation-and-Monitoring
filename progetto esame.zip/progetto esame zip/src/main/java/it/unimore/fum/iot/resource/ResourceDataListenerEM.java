package it.unimore.fum.iot.resource;




public interface ResourceDataListenerEM<K> {

    public void onDataChanged(EnvironmentalMonitoringSmartObjectResource<K> resource, K updatedValue);

}
